-- autoexec2.lua — variant for one-shot GTE+GPUSTAT+VRAM observation.
-- Same plugin entry-point used by pcsx-redux via -archive.

local function register_handlers()
    if not PCSX.WebServer then PCSX.WebServer = {} end
    if not PCSX.WebServer.Handlers then PCSX.WebServer.Handlers = {} end

    -- Per the user's empirical-debug directive, observe live GTE + GPUSTAT.
    -- Without the gdb stub, the Lua API is the only view of COP2 state.

    local function fmt32(v)
        v = tonumber(v) or 0
        if v < 0 then v = v + 2^32 end
        return string.format("0x%08x", v)
    end

    PCSX.WebServer.Handlers.gte = function(req)
        local r = PCSX.getRegisters()
        local out = { "pc=0x" .. string.format("%x", r.pc) }
        for i = 0, 31 do
            out[#out + 1] = string.format("D[%d]=%s C[%d]=%s",
                i, fmt32(r.CP2D.r[i]), i, fmt32(r.CP2C.r[i]))
        end
        return table.concat(out, "\n")
    end

    PCSX.WebServer.Handlers.gpustat = function(req)
        if not PCSX.GPU or not PCSX.GPU.gpuReadStatus then
            return "GPUSTAT=NOT_AVAILABLE"
        end
        local ok, s = pcall(PCSX.GPU.gpuReadStatus)
        if not ok then return "GPUSTAT_READ_FAIL=" .. tostring(s) end
        return "GPUSTAT=" .. fmt32(s) .. "\nready=" .. tostring((s >> 31) & 1)
            .. "\nDMAdir=0x" .. string.format("%x", (s >> 29) & 3)
            .. "\ndisp_enable=" .. tostring((s >> 0) & 1)
    end

    PCSX.WebServer.Handlers.vram_dump = function(req)
        if not PCSX.GPU or not PCSX.GPU.vramDump then
            return "VRAM=NOT_AVAILABLE"
        end
        local ok, data = pcall(PCSX.GPU.vramDump)
        if not ok then return "VRAM_DUMP_FAIL=" .. tostring(data) end
        local count = #data
        local nonzero = 0
        local first16 = {}
        for i = 1, math.min(16, count) do
            first16[#first16 + 1] = string.format("%02x", data[i])
        end
        local sample_window = data[1] or 0
        local around_pixel_120 = {}
        for j = 119, 121 do
            if data[j] then around_pixel_120[#around_pixel_120 + 1] = string.format("%02x", data[j]) end
        end
        return string.format("VRAM size=%d nonzero=unknown first16=[%s] byte119-121=[%s]",
            count, table.concat(first16, " "), table.concat(around_pixel_120, " "))
    end

end

local ok, err = pcall(register_handlers)
if ok then
    print("[gd_handler] handlers registered: gte, gpustat, vram_dump")
else
    print("[gd_handler] registration failed: " .. tostring(err))
end
